$(function(){
	$('.header').load('../head.html');
	$('.left').load('../left.html');
});
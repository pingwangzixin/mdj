$(function(){
    //切换列表
    $(document).on("click",".wx_qh a span",function(){
        $(this).addClass("active").parent().siblings().children().removeClass("active")
    })
})


